1. The chatbot and forget password (esqueceu a senha?) isn't working. I tried to finish, but I can't

 O chat bot e o esqueceu a senha não está funcionando. Eu tentei consertar, mas não consegui