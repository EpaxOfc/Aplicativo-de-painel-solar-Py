DROP DATABASE IF EXISTS solarApp;
CREATE DATABASE IF NOT EXISTS solarApp;
USE solarApp;

CREATE TABLE IF NOT EXISTS solarPainel (
    idPainel INTEGER NOT NULL AUTO_INCREMENT,
    numeroSerie INTEGER NOT NULL,
    fabricante CHAR(100) NULL,
    PRIMARY KEY (idPainel)
);

CREATE TABLE IF NOT EXISTS usuario (
    id INTEGER NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    cpf VARCHAR(15) NOT NULL,
    telefone CHAR(18) NOT NULL,
    nascimento DATE NOT NULL,
    email CHAR(120) NOT NULL,
    senha CHAR(24) NOT NULL,
    endereco CHAR(150) NOT NULL,
    idPainel INTEGER,
    PRIMARY KEY (id),
    FOREIGN KEY (idPainel) REFERENCES solarPainel(idPainel)
);

CREATE TABLE IF NOT EXISTS producao(
    id INTEGER AUTO_INCREMENT,
    producao_30m INT NULL,
    dataHora DATETIME NOT NULL,
    idPainel INT NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (idPainel) REFERENCES solarPainel(idPainel)
);
