import tkinter as tk
from tkinter import messagebox
from Data import get_db_connection
from Style import *

def save_changes(user_id, new_email, new_password, new_panel_number):
    new_email_value = new_email.get()
    new_password_value = new_password.get()
    new_panel_number_value = new_panel_number.get()

    db = get_db_connection()
    cursor = db.cursor()

    
    cursor.execute("SELECT idPainel FROM solarPainel WHERE idPainel = %s", (new_panel_number_value,))
    panel_exists = cursor.fetchone()

    if not panel_exists:
        messagebox.showerror("Erro", "O número do painel solar não existe.")
        return

    if new_email_value and new_password_value and new_panel_number_value:
        try:
            cursor.execute("UPDATE usuario SET email=%s, senha=%s, idPainel=%s WHERE id=%s",
                           (new_email_value, new_password_value, new_panel_number_value, user_id))
            db.commit()
            messagebox.showinfo("Sucesso", "Dados atualizados com sucesso.")
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao atualizar dados: {e}")
        finally:
            db.close()
    else:
        messagebox.showerror("Erro", "Todos os campos são obrigatórios.")

def create_change_page(user_id):
    root = tk.Tk()
    root.geometry("400x400")
    root.configure(bg=BACKGROUND_COLOR)
    root.resizable(False, False)

    frame = tk.Frame(root, width=350, height=350, bg=PADDING_COLOR, padx=30, pady=30)
    frame.pack(pady=25)

    email_label = tk.Label(frame, text="Novo Email", bg=PADDING_COLOR)
    email_label.pack(pady=5)
    email_entry = tk.Entry(frame)
    email_entry.pack(pady=5)

    password_label = tk.Label(frame, text="Nova Senha", bg=PADDING_COLOR)
    password_label.pack(pady=5)
    password_entry = tk.Entry(frame, show="*")
    password_entry.pack(pady=5)

    panel_label = tk.Label(frame, text="Número do painel solar", bg=PADDING_COLOR)
    panel_label.pack(pady=5)
    panel_entry = tk.Entry(frame)
    panel_entry.pack(pady=5)

    save_button = tk.Button(frame, text="Salvar", bg=BUTTON_CLICK_COLOR, command=lambda: save_changes(user_id, email_entry, password_entry, panel_entry))
    save_button.pack(pady=20)

    root.mainloop()
