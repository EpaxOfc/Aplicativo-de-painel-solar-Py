import tkinter as tk
from tkinter import messagebox
import webbrowser
import os  
from Data import get_db_connection
from Style import *

def delete_account(user_id):
    db = get_db_connection()
    cursor = db.cursor()
    try:
        cursor.execute("DELETE FROM usuario WHERE id=%s", (user_id,))
        db.commit()
        messagebox.showinfo("Conta excluída", "Sua conta foi excluída com sucesso.")
        go_to_home(root)
    except Exception as e:
        messagebox.showerror("Erro", f"Erro ao excluir conta: {e}")
    finally:
        db.close()

def go_to_home(root):
    from Main_page import logout
    logout(root)
    import Home_page

def open_chatbot():
    
    chatbot_directory = os.path.join(os.path.dirname(__file__), 'chatbot')
    chatbot_script = os.path.join(chatbot_directory, 'app.py')

    
    os.system(f'start cmd /K "python {chatbot_script}"')

    
    webbrowser.open("http://127.0.0.1:5000")

def create_config_page(user_id):
    global root
    root = tk.Tk()
    root.geometry("250x300")
    root.configure(bg="#163070")

    frame = tk.Frame(root, width=200, height=150, bg="#D3D3D3", padx=30, pady=30)
    frame.pack(pady=25)

    delete_button = tk.Button(frame, text="Excluir conta", bg=BUTTON_CLICK_COLOR, command=lambda: delete_account(user_id))
    delete_button.pack(pady=20)

    chatbot_button = tk.Button(frame, text="Chatbot de Atendimento", bg=BUTTON_CLICK_COLOR, command=open_chatbot)
    chatbot_button.pack(pady=10)

    root.mainloop()
