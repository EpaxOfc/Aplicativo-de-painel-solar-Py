# Home_page.py
import tkinter as tk
from Style import *

def go_to_login():
    root.destroy()
    import Login_page

def go_to_register():
    root.destroy()
    import Register_page

root = tk.Tk()
root.geometry("600x535")
root.configure(bg=BACKGROUND_COLOR)
root.resizable(False, False)

frame = tk.Frame(root, width=600, height=535, bg=BACKGROUND_COLOR)
frame.pack(expand=True)

label = tk.Label(frame, text="Entre se já tiver uma conta ou se cadastre", fg="white", bg=BACKGROUND_COLOR, font=("Helvetica", 16, "bold"))
label.pack(pady=20)

button_frame = tk.Frame(frame, bg=BACKGROUND_COLOR)
button_frame.pack(pady=10)

login_button = tk.Button(button_frame, text="Log in", bg=BUTTON_COLOR, fg="white", command=go_to_login)
login_button.pack(side="left", padx=5)
apply_hover_effects(login_button, BUTTON_HOVER_COLOR, BUTTON_COLOR)

register_button = tk.Button(button_frame, text="Cadastrar", bg=BUTTON_COLOR, fg="white", command=go_to_register)
register_button.pack(side="left", padx=5)
apply_hover_effects(register_button, BUTTON_HOVER_COLOR, BUTTON_COLOR)

root.mainloop()
