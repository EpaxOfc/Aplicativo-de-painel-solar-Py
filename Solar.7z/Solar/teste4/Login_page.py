#login-page
import tkinter as tk
from tkinter import messagebox
import mysql.connector
import webbrowser
import os
from Style import *
from Data import get_db_connection

db = get_db_connection()

def login():
    email = entry_email.get()
    password = entry_password.get()

    if email and password:
        try:
            with db.cursor() as cursor:
                cursor.execute("SELECT id FROM usuario WHERE email=%s AND senha=%s", (email, password))
                result = cursor.fetchone()

                if result:
                    user_id = result[0]
                    messagebox.showinfo("Login bem-sucedido", "Login bem-sucedido")
                    go_to_main(user_id)
                    db.close()
                else:
                    messagebox.showerror("Erro", "Informações erradas")
        except mysql.connector.Error as err:
            messagebox.showerror("Erro", f"Erro no banco de dados: {err}")
            db.close()
    else:
        messagebox.showerror("Erro", "Por favor, preencha todos os campos")

def go_to_main(user_id):
    root.destroy()
    import Main_page
    Main_page.main(user_id)

def voltar():
    root.destroy()
    import Home_page

def open_password_recovery():
    webbrowser.open("http://127.0.0.1:5000")


root = tk.Tk()
root.geometry("640x500")
root.configure(bg=BACKGROUND_COLOR)
root.resizable(False, False)

frame = tk.Frame(root, width=600, height=540, bg=PADDING_COLOR, padx=100, pady=40)
frame.pack(pady=10)

label_email = tk.Label(frame, text="Email", bg=PADDING_COLOR)
label_email.pack(pady=5)
entry_email = tk.Entry(frame)
entry_email.pack(pady=5)

label_password = tk.Label(frame, text="Senha", bg=PADDING_COLOR)
label_password.pack(pady=5)
entry_password = tk.Entry(frame, show="*")
entry_password.pack(pady=5)

login_button = tk.Button(frame, text="Log in", bg=BUTTON_CLICK_COLOR, command=login)
login_button.pack(pady=20, padx=20)
apply_hover_effects(login_button, BUTTON_REGISTER_HOVER_COLOR, BUTTON_CLICK_COLOR)

forgot_password_label = tk.Label(frame, text="Esqueceu a senha?", fg="blue", cursor="hand2", bg=PADDING_COLOR)
forgot_password_label.pack(pady=5)
forgot_password_label.bind("<Button-1>", lambda e: open_password_recovery())

back_button = tk.Button(frame, text="Voltar", bg=BUTTON_CLICK_COLOR, command=voltar)
back_button.pack(pady=5)
apply_hover_effects(back_button, BUTTON_REGISTER_HOVER_COLOR, BUTTON_CLICK_COLOR)

root.mainloop()
