# Main_page.py
import tkinter as tk
from Style import BACKGROUND_COLOR, PADDING_COLOR
from Data import get_db_connection

def open_sidebar(root, user_id):
    sidebar = tk.Toplevel(root)
    sidebar.geometry("200x200")
    sidebar.title("Sidebar")

    perfil_button = tk.Button(sidebar, text="Perfil", command=lambda: open_perfil(root, user_id))
    perfil_button.pack(pady=10)

    config_button = tk.Button(sidebar, text="Configurações", command=lambda: open_config(root, user_id))
    config_button.pack(pady=10)

    logout_button = tk.Button(sidebar, text="Log out", command=lambda: logout(root))
    logout_button.pack(pady=10)

def open_perfil(root, user_id):
    import Perfil_page
    Perfil_page.create_perfil_page(user_id)

def open_config(root, user_id):
    import Config_page
    Config_page.create_config_page(user_id)

def logout(root):
    root.destroy()
    import Home_page
    Home_page.main()

def fetch_production_data(user_id):
    db = get_db_connection()
    cursor = db.cursor()
    cursor.execute("""
        SELECT p.producao_30m 
        FROM producao p 
        JOIN usuario u ON p.idPainel = u.idPainel 
        WHERE u.id = %s 
        ORDER BY p.dataHora DESC 
        LIMIT 1
    """, (user_id,))
    production_data = cursor.fetchone()
    db.close()
    return production_data[0] if production_data else 0

def calculate_totals(production_data):
    total_generated_month = production_data * 48 * 30
    total_savings = total_generated_month * 0.024
    return total_generated_month, total_savings

def main(user_id):
    production_data = fetch_production_data(user_id)
    total_generated_month, total_savings = calculate_totals(production_data)

    root = tk.Tk()
    root.geometry("1150x950")
    root.configure(bg=BACKGROUND_COLOR)
    root.resizable(False, False)

    upper_bar = tk.Frame(root, width=1150, height=64, bg="#FFFF00")
    upper_bar.pack(side="top", fill="x")

    label = tk.Label(upper_bar, text="Smart Solar", bg="#FFFF00", font=("Helvetica", 16, "bold"))
    label.pack(side="left", padx=20)

    profile_button = tk.Button(upper_bar, text="Profile", bg="#FFFFFF", command=lambda: open_sidebar(root, user_id))
    profile_button.pack(side="right", padx=20)

    frame = tk.Frame(root, width=1000, height=830, bg=PADDING_COLOR)
    frame.pack(expand=True)

    labels = ["Quantidade de energia gerada", "Total gerado no mês", "Economia Total"]
    values = [f"{production_data} Wh", f"{total_generated_month} Wh", f"+R$ {total_savings:.2f}"]
    deltas = ["+20% em relação a ontem", "+33% em relação a mês passado", ""]

    cards_frame = tk.Frame(frame, bg=PADDING_COLOR)
    cards_frame.pack(expand=True)

    for i in range(3):
        card = tk.Frame(cards_frame, bg="white", padx=20, pady=20, bd=1, relief="solid")
        card.grid(row=0, column=i, padx=10, pady=10)
        tk.Label(card, text=labels[i], bg="white", font=("Helvetica", 12)).pack()
        tk.Label(card, text=values[i], bg="white", font=("Helvetica", 24, "bold")).pack()
        tk.Label(card, text=deltas[i], bg="white", font=("Helvetica", 10)).pack()

    root.mainloop()

if __name__ == "__main__":
    user_id = 1 
    main(user_id)
