import tkinter as tk
from Data import get_db_connection
from Style import *

def fetch_user_data(user_id):
    db = get_db_connection()
    cursor = db.cursor()
    try:
        cursor.execute("SELECT nome, cpf, telefone, nascimento, email, endereco FROM usuario WHERE id=%s", (user_id,))
        user_data = cursor.fetchone()
    except Exception as e:
        print(f"Ocorreu um erro: {e}")
        user_data = None
    finally:
        db.close()
    return user_data

def toggle_visibility(label, is_hidden):
    if is_hidden:
        label.config(text="*********")
    else:
        label.config(text=label.cget("text"))
    return not is_hidden

def create_perfil_page(user_id):
    user_data = fetch_user_data(user_id)
    
    root = tk.Tk()
    root.geometry("500x700")
    root.configure(bg="#163074")

    frame = tk.Frame(root, width=350, height=450, bg="#D3D3D3", padx=30, pady=30)
    frame.pack(pady=25)

    if user_data is None:
        error_label = tk.Label(frame, text="Erro: Não foi possível buscar os dados do usuário.", bg="#D3D3D3", fg="red")
        error_label.pack(pady=5)
    else:
        labels_texts = ["Nome", "CPF", "Telefone", "Data de Nascimento", "Email", "Endereço"]
        is_hidden_cpf = True  
        is_hidden_password = True

        for i, text in enumerate(labels_texts):
            label = tk.Label(frame, text=f"{text}: ", bg="#D3D3D3")
            label.pack(pady=5)
            value = tk.Label(frame, text=user_data[i] if i != 1 else "*********", bg="#D3D3D3") 
            value.pack(pady=5)
            if i == 1:  
                toggle_button = tk.Button(frame, text="Mostrar", command=lambda v=value: toggle_visibility(v, is_hidden_cpf))
                toggle_button.pack(pady=5)
                is_hidden_cpf = toggle_visibility(value, is_hidden_cpf)
            if i == 4:  
                change_button = tk.Button(frame, text="Change", command=lambda: open_change_page(user_id))
                change_button.pack(pady=5)

        password_label = tk.Label(frame, text="Senha: ", bg="#D3D3D3")
        password_label.pack(pady=5)
        password_value = tk.Label(frame, text="******", bg="#D3D3D3")
        password_value.pack(pady=5)
        toggle_password_button = tk.Button(frame, text="Mostrar", command=lambda: toggle_visibility(password_value, is_hidden_password))
        toggle_password_button.pack(pady=5)
        is_hidden_password = toggle_visibility(password_value, is_hidden_password)

    root.mainloop()

def open_change_page(user_id):
    import Change_page
    Change_page.create_change_page(user_id)
