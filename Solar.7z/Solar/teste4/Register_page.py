import tkinter as tk
from tkinter import messagebox
import mysql.connector
from Style import *
from Data import get_db_connection
from datetime import datetime

def validate_date(date_text):
    for fmt in ('%d/%m/%Y', '%d-%m-%Y'):
        try:
            return datetime.strptime(date_text, fmt).date()
        except ValueError:
            continue
    raise ValueError("Formato de data incorreto. Use DD/MM/YYYY ou DD-MM-YYYY.")

def is_number(s):
    try:
        int(s)
        return True
    except ValueError:
        return False

db = get_db_connection()

def register():
    nome = entry_name.get()
    cpf = entry_cpf.get()
    endereco = entry_address.get()
    telefone = entry_phone.get()
    nascimento = entry_dob.get()
    email = entry_email.get()
    senha = entry_password.get()
    confirmar_senha = entry_confirm_password.get()
    numero_painel = entry_panel.get()

    try:
        nascimento = validate_date(nascimento)
    except ValueError as ve:
        messagebox.showerror("Erro", str(ve))
        return

    if not all(is_number(field) for field in [cpf, telefone, numero_painel]):
        messagebox.showerror("Erro", "CPF, Telefone e Número do Painel Solar devem conter apenas números.")
        return

    if not (6 <= len(senha) <= 16):
        messagebox.showerror("Erro", "A senha deve ter entre 6 e 16 caracteres.")
        return

    if not email.endswith('@gmail.com'):
        messagebox.showerror("Erro", "O email deve ser um endereço @gmail.com.")
        return

    if all([nome, cpf, endereco, telefone, nascimento, email, senha, confirmar_senha, numero_painel]):
        if senha == confirmar_senha:
            cursor = db.cursor()
            cursor.execute("SELECT email FROM usuario WHERE email=%s", (email,))
            if cursor.fetchone():
                messagebox.showerror("Erro", "Email já registrado")
                return

            cursor.execute("SELECT idPainel FROM solarPainel WHERE numeroSerie = %s", (numero_painel,))
            painel = cursor.fetchone()
            if painel:
                id_painel = painel[0]
            else:
                messagebox.showerror("Erro", "Número de painel solar inexistente")
                return

            cursor.execute("INSERT INTO usuario (nome, cpf, telefone, nascimento, email, senha, endereco, idPainel) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
                           (nome, cpf, telefone, nascimento, email, senha, endereco, id_painel))
            db.commit()
            db.close()
            messagebox.showinfo("Registrado com sucesso", "Registrado com sucesso")
            go_to_home()
        else:
            messagebox.showerror("Erro", "As senhas não coincidem")
    else:
        messagebox.showerror("Erro", "Todos os campos são obrigatórios")

def go_to_home():
    root.destroy()
    import Home_page

def voltar():
    root.destroy()
    import Home_page

root = tk.Tk()
root.geometry("640x670")
root.configure(bg=BACKGROUND_COLOR)
root.resizable(False, False)

frame = tk.Frame(root, width=600, height=520, bg=PADDING_COLOR, padx=150, pady=30)
frame.pack(pady=5, padx=100)

entries = []
labels_texts = ["Nome", "CPF", "Telefone", "Data de Nascimento", "Endereço", "Número do Painel Solar", "Email", "Senha", "Confirmar Senha"]
for text in labels_texts:
    label = tk.Label(frame, text=text, bg=PADDING_COLOR)
    label.pack(pady=3)
    entry = tk.Entry(frame, width=700)
    entry.pack(pady=4)
    entries.append(entry)

entry_name, entry_cpf, entry_phone, entry_dob, entry_address, entry_panel, entry_email, entry_password, entry_confirm_password = entries

register_button = tk.Button(frame, text="Cadastrar", bg=BUTTON_CLICK_COLOR, command=register)
register_button.pack(pady=10)
apply_hover_effects(register_button, BUTTON_REGISTER_HOVER_COLOR, BUTTON_CLICK_COLOR)

back_button = tk.Button(frame, text="Voltar", bg=BUTTON_CLICK_COLOR, command=voltar)
back_button.pack(pady=10)
apply_hover_effects(back_button, BUTTON_REGISTER_HOVER_COLOR, BUTTON_CLICK_COLOR)

root.mainloop()
