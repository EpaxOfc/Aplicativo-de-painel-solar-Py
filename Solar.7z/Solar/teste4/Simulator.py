import mysql.connector
from mysql.connector import errorcode
import random
from datetime import datetime, timedelta


config = {
    'user': 'root',
    'password': '#Ladynoir1',
    'host': 'localhost',
    'database': 'solarApp',
    'port': '3307',
}

try:
    cnx = mysql.connector.connect(**config)
    cursor = cnx.cursor()

    solar_panels = [
        (123456, 'SolarTech'),
        (789012, 'EcoSun'),
        (345678, 'SunPower'),
        (901234, 'BrightSolar'),
        (567890, 'GreenEnergy')
    ]

    cursor.executemany(
        "INSERT INTO solarPainel (numeroSerie, fabricante) VALUES (%s, %s)", 
        solar_panels
    )

    cursor.execute("SELECT idPainel FROM solarPainel")
    panel_ids = [row[0] for row in cursor.fetchall()]


    start_date = datetime(2024, 1, 1)
    end_date = datetime(2024, 1, 2)
    current_date = start_date

    production_data = []

    while current_date < end_date:
        for panel_id in panel_ids:
            production_30m = random.randint(0, 500) 
            production_data.append((production_30m, current_date, panel_id))
        current_date += timedelta(minutes=30)


    cursor.executemany(
        "INSERT INTO producao (producao_30m, dataHora, idPainel) VALUES (%s, %s, %s)", 
        production_data
    )

    cnx.commit()

except mysql.connector.Error as err:
    if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
        print("Something is wrong with your user name or password")
    elif err.errno == errorcode.ER_BAD_DB_ERROR:
        print("Database does not exist")
    else:
        print(err)
finally:
    cursor.close()
    cnx.close()
