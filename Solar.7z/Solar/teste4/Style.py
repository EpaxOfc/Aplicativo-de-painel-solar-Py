# Style.py
import tkinter as tk
from tkinter import messagebox

BACKGROUND_COLOR = "#163074"
PADDING_COLOR = "#D3D3D3"
BUTTON_COLOR = "#000000"
BUTTON_HOVER_COLOR = "#ADD8E6"
BUTTON_CLICK_COLOR = "#FFFF00"
BUTTON_REGISTER_HOVER_COLOR = "#D8BFD8"

def apply_hover_effects(button, color_on_hover, color_on_leave):
    button.bind("<Enter>", lambda e: button.config(bg=color_on_hover))
    button.bind("<Leave>", lambda e: button.config(bg=color_on_leave))

def show_popup(message, title="Info"):
    messagebox.showinfo(title, message)

def show_error(message, title="Error"):
    messagebox.showerror(title, message)
