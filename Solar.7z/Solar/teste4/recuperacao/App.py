from flask import Flask, render_template, request, flash, redirect, url_for
import pymysql
import os
from dotenv import load_dotenv
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# Carregar variáveis de ambiente do arquivo .env
load_dotenv('tst.env')

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Configuração do banco de dados
db = pymysql.connect(
    host='localhost',
    user='root',
    password=os.getenv('DB_PASSWORD'),
    database='solarApp',
    port=3307,
    cursorclass=pymysql.cursors.DictCursor
)

def send_email(recipient, subject, body):
    sender_email = os.getenv('MAIL_USERNAME')
    sender_password = os.getenv('MAIL_PASSWORD')

    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = recipient
    msg['Subject'] = subject

    msg.attach(MIMEText(body, 'plain'))

    try:
        with smtplib.SMTP('smtp.office365.com', 587) as server:
            server.starttls()
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, recipient, msg.as_string())
            server.quit()
        return True
    except Exception as e:
        print(f"Erro ao enviar e-mail: {str(e)}")
        return False

@app.route('/')
def index():
    return render_template('recuperarsenha.html')

@app.route('/recuperar_senha', methods=['POST'])
def recuperar_senha():
    email = request.form['email']

    with db.cursor() as cursor:
        cursor.execute("SELECT senha, nome FROM usuario WHERE email = %s", (email,))
        usuario = cursor.fetchone()

    if usuario:
        senha = usuario['senha']
        nome = usuario['nome']

        subject = 'Recuperação de Senha - SolarApp'
        body = f"Olá {nome},\n\nSua senha no SolarApp é: {senha}\n\nAtenciosamente,\nEquipe SolarApp"
        
        if send_email(email, subject, body):
            flash(f"Um e-mail com sua senha foi enviado para {email}", "success")
        else:
            flash(f"Erro ao enviar e-mail. Por favor, tente novamente.", "error")
    else:
        flash("E-mail não encontrado. Por favor, verifique o e-mail digitado.", "error")

    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
