document.addEventListener('DOMContentLoaded', (event) => {
    const form = document.getElementById('recoveryForm');

    form.addEventListener('submit', function(event) {
        const email = document.getElementById('email').value;
        
        if (!validateEmail(email)) {
            event.preventDefault(); 
            alert('Por favor, insira um endereço de e-mail válido.');
        }
    });

    function validateEmail(email) {
        const re = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        return re.test(String(email).toLowerCase());
    }
});
